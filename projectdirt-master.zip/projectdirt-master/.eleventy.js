module.exports = {
    dir: {
        input: 'src',
        output: 'dist',
    },
}
