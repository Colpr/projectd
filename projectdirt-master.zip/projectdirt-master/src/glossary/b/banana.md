---
layout: item.njk
title: Banana
url: /glossary/b/banana/
tags:
    - yellow
    - seedless
    - fruit
---

ba·nan·a
/bəˈnanə/

1. a long curved fruit which grows in clusters and has soft pulpy flesh and yellow skin when ripe.
2. the tropical and subtropical palmlike plant that bears bananas, having very large leaves but lacking a woody trunk.
