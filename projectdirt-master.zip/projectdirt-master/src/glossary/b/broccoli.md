---
layout: item.njk
title: Broccoli
url: /glossary/b/broccoli/
tags:
    - green
    - seedless
    - tree-like
    - vegetable
---

broc·co·li
/ˈbräk(ə)lē/

a cultivated variety of cabbage bearing heads of green or purplish flower buds that are eaten as a vegetable.
