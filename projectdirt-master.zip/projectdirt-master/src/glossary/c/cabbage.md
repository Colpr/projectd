---
layout: item.njk
title: Cabbage
url: /glossary/c/cabbage/
tags:
    - green
    - round
    - seedless
    - vegetable
---

cab·bage
/ˈkabij/

a cultivated plant eaten as a vegetable, having thick green or purple leaves surrounding a spherical heart or head of young leaves.
