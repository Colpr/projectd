---
layout: item.njk
title: Cantaloupe
url: /glossary/c/cantaloupe/
tags:
    - orange
    - seeds
    - round
    - fruit
---

can·ta·loupe
/ˈkan(t)əˌlōp/

a small round melon of a variety with orange flesh and ribbed skin.
