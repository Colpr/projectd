---
layout: item.njk
title: Carrot
url: /glossary/c/carrot/
tags:
    - vegetable
    - orange
    - root
---

car·rot
/ˈkerət/

1. a tapering orange-colored root eaten as a vegetable.
2. the cultivated feathery-leaved plant of the parsley family that yields this vegetable.
