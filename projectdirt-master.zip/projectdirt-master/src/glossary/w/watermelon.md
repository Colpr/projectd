---
layout: item.njk
title: Watermelon
url: /glossary/w/watermelon/
tags:
    - green
    - round
    - seeds
    - seedless
    - red
    - gourd
    - fruit
---

wa·ter·mel·on
/ˈwôdərˌmelən,ˈwädərˌmelən/

1. the large fruit of a plant of the gourd family, with smooth green skin, red pulp, and watery juice.

2. the widely cultivated African plant that yields the watermelon.
