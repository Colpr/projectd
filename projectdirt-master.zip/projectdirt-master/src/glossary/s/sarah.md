---
layout: item.njk
title: Sarah Leung
url: /glossary/s/sarah/
tags:
    - leung
    - female
---

Female - 8th or 9th grade?

1. Still watches dora the explore and veggie tales occasionaly

Info provided by: Someone who knows her