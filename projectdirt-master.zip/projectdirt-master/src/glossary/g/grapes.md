---
layout: item.njk
title: Grapes
url: /glossary/g/grapes/
tags:
    - green
    - purple
    - round
    - seedless
    - seeds
    - red
    - black
    - fruit
---

grape
/ɡrāp/

1. a berry, typically green (classified as white), purple, red, or black, growing in clusters on a grapevine, eaten as fruit, and used in making wine.

2. short for grapeshot.
