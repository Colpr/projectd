---
layout: item.njk
title: Lettuce
url: /glossary/l/lettuce/
tags:
    - green
    - leafy
    - vegetable
---

let·tuce
/ˈledəs/

1. a cultivated plant of the daisy family, with edible leaves that are a usual ingredient of salads. Many varieties of lettuce have been developed with a range of form, texture, and color.

2. paper money; greenbacks.
