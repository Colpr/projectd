---
layout: item.njk
title: Avocado
url: /glossary/a/avocado/
tags:
    - green
    - seeds
    - fruit
---

av·o·ca·do
/ˌavəˈkädō,ˌävəˈkädō/

1. a pear-shaped fruit with a rough leathery skin, smooth oily edible flesh, and a large stone.
   "serve with slices of avocado"
2. the tropical evergreen tree that bears the avocado, native to Central America and widely cultivated elsewhere.
