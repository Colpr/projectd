---
layout: item.njk
title: Apple
url: /glossary/a/apple/
tags:
    - round
    - red
    - seeds
    - fruit
---

ap·ple
/ˈapəl/

1. the round fruit of a tree of the rose family, which typically has thin red or green skin and crisp flesh. Many varieties have been developed as dessert or cooking fruit or for making cider.
2. the tree which bears apples.
