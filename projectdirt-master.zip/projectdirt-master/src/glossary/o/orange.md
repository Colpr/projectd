---
layout: item.njk
title: Orange
url: /glossary/o/orange/
tags:
    - orange
    - seeds
    - seedless
    - round
    - fruit
---

or·ange
/ˈôrənj,ˈärənj/

1. a round juicy citrus fruit with a tough bright reddish-yellow rind.

2. the leathery-leaved evergreen tree that bears the orange, native to warm regions of South and Southeast Asia. Oranges are a major commercial crop in many warm regions of the world.
