---
layout: item.njk
title: Onion
url: /glossary/o/onion/
tags:
    - yellow
    - round
    - layers
    - white
    - vegetable
---

on·ion
/ˈənyən/

1. an edible bulb with a pungent taste and smell, composed of several concentric layers, used in cooking.
   "cook the onion in the oil until lightly colored"
2. the plant that produces the onion, with long rolled or straplike leaves and spherical heads of greenish-white flowers.
