---
layout: item.njk
title: Eggplant
url: /glossary/e/eggplant/
tags:
    - purple
    - nightshade
    - vegetable
---

egg·plant
/ˈeɡˌplant/

1. the purple egg-shaped fruit of a tropical Old World plant, which is eaten as a vegetable.
2. the large plant of the nightshade family that bears the eggplant fruit.
